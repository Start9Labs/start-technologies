Generated from production source at 795d8a265 (formats 1/2/3 before replay-binding changes).
v1: password=password; root inode 1, raw packed record 42 and legacy blobs.
v2: password=snapshots; inode2=frozen-inline, inode3=12000 bytes0x42, inode4=4 chunks0x31.
v3: same inodes/password; snapshots before(4 original chunks), after(versioned at chunk1+123); live truncated to2 chunks.
